<div>
<ul class="nav navbar-nav">
	<li><a href="index.php">Home</a></li>
	<li><a href="?p=createProject">Create</a></li>
	<li><a href="page/logout.php">Logout</a></li>
</ul>
</div>


